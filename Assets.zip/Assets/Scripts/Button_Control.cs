using UnityEngine;
using UnityEngine.SceneManagement;
public class Button_Control : MonoBehaviour
{
    public void NextScene()
    {
        SceneManager.LoadScene("SampleScene");
    }
}

